# Flood Extent Extraction #

Collection of user ready notebooks / apps for the extraction of flood extents from aerial imagery. 

## Steps 
Basic steps to get up and running

- Start Sagemaker Notebook
- Clone this respository
- Check app documentation for system setup
- Configure app 
- Run
